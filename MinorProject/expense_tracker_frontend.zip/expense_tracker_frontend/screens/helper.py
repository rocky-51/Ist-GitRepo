expensetracker="""
<LoginScreen>:
    MDScreen :
        md_bg_color : [35/255,59/255,54/255,1]
        MDCard :
            size_hint : None,None
            size : 800,600
            pos_hint : {"center_x":.5,"center_y":.5}
            elevation : 15
            md_bg_color : [50/255,50/255,50/255,1]
            padding : 20
            spacing : 30
            orientation : "vertical"
            MDLabel:
                text: "Welcome Back!"
                halign: "center"
                font_style: "H4"
                theme_text_color: "Custom"
            MDTextField:
                id: email
                hint_text:"Enter Username "
                size_hint_x: None
                helper_text:"or click on 'click here'"
                helper_text_mode:'on_focus'
                width: "200dp"
                valign:'top'
                pos_hint: {'bottom':0.5,"center_x": .5, "center_y": .5}
            MDTextField:
                id: password
                hint_text:"Enter Password "
                helper_text:"or click on 'click here'"
                helper_text_mode:'on_focus'
                password: True
                size_hint_x: None
                width: "200dp"
                pos_hint: {"center_x": .5, "center_y": .3}
            MDRoundFlatButton :
                text : 'LOGIN'
                pos_hint : {"center_x":.5}
                font_size : 15
                on_release: root.login()
            Widget :
                size_hint_y : None
                height : 30
            MDRoundFlatButton :
                text: "New user? Register here"
                pos_hint: {"center_x": 0.5}
                on_release: root.manager.current = "register"
"""